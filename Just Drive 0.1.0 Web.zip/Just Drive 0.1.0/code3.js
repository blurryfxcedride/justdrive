gdjs._49Code = {};
gdjs._49Code.GDStatueObjects1= [];
gdjs._49Code.GDStatueObjects2= [];
gdjs._49Code.GDWiderectanglestoneObjects1= [];
gdjs._49Code.GDWiderectanglestoneObjects2= [];
gdjs._49Code.GDPlayerBulletObjects1= [];
gdjs._49Code.GDPlayerBulletObjects2= [];
gdjs._49Code.GDTilesetPiece55Objects1= [];
gdjs._49Code.GDTilesetPiece55Objects2= [];
gdjs._49Code.GDpolicecarObjects1= [];
gdjs._49Code.GDpolicecarObjects2= [];
gdjs._49Code.GDEnemyBulletObjects1= [];
gdjs._49Code.GDEnemyBulletObjects2= [];
gdjs._49Code.GDGameOverObjects1= [];
gdjs._49Code.GDGameOverObjects2= [];
gdjs._49Code.GDTutorialTextObjects1= [];
gdjs._49Code.GDTutorialTextObjects2= [];
gdjs._49Code.GDScoreObjects1= [];
gdjs._49Code.GDScoreObjects2= [];
gdjs._49Code.GDHighScoreObjects1= [];
gdjs._49Code.GDHighScoreObjects2= [];
gdjs._49Code.GDBluePowerupObjects1= [];
gdjs._49Code.GDBluePowerupObjects2= [];
gdjs._49Code.GDMetalRedBarObjects1= [];
gdjs._49Code.GDMetalRedBarObjects2= [];
gdjs._49Code.GDHitObjects1= [];
gdjs._49Code.GDHitObjects2= [];
gdjs._49Code.GDClickPointObjects1= [];
gdjs._49Code.GDClickPointObjects2= [];
gdjs._49Code.GDRoadObjects1= [];
gdjs._49Code.GDRoadObjects2= [];
gdjs._49Code.GDRoadLineObjects1= [];
gdjs._49Code.GDRoadLineObjects2= [];
gdjs._49Code.GDGrassObjects1= [];
gdjs._49Code.GDGrassObjects2= [];
gdjs._49Code.GDAmphibiousCarYellowObjects1= [];
gdjs._49Code.GDAmphibiousCarYellowObjects2= [];
gdjs._49Code.GDCarRedObjects1= [];
gdjs._49Code.GDCarRedObjects2= [];
gdjs._49Code.GDConvertiblePurpleObjects1= [];
gdjs._49Code.GDConvertiblePurpleObjects2= [];
gdjs._49Code.GDConvertibleBlueObjects1= [];
gdjs._49Code.GDConvertibleBlueObjects2= [];
gdjs._49Code.GDAmphibiousCarBlueObjects1= [];
gdjs._49Code.GDAmphibiousCarBlueObjects2= [];
gdjs._49Code.GDCarBlueObjects1= [];
gdjs._49Code.GDCarBlueObjects2= [];
gdjs._49Code.GDCoupeBlueObjects1= [];
gdjs._49Code.GDCoupeBlueObjects2= [];
gdjs._49Code.GDF1CarLightBlueObjects1= [];
gdjs._49Code.GDF1CarLightBlueObjects2= [];
gdjs._49Code.GDF1CarBrownObjects1= [];
gdjs._49Code.GDF1CarBrownObjects2= [];
gdjs._49Code.GDF1CarRedObjects1= [];
gdjs._49Code.GDF1CarRedObjects2= [];
gdjs._49Code.GDCoupeYellowObjects1= [];
gdjs._49Code.GDCoupeYellowObjects2= [];
gdjs._49Code.GDJeepBriteGreenObjects1= [];
gdjs._49Code.GDJeepBriteGreenObjects2= [];
gdjs._49Code.GDFuelSemiTruckObjects1= [];
gdjs._49Code.GDFuelSemiTruckObjects2= [];
gdjs._49Code.GDJeepGreenObjects1= [];
gdjs._49Code.GDJeepGreenObjects2= [];
gdjs._49Code.GDMuscleCarBlueObjects1= [];
gdjs._49Code.GDMuscleCarBlueObjects2= [];
gdjs._49Code.GDSedanGreenObjects1= [];
gdjs._49Code.GDSedanGreenObjects2= [];
gdjs._49Code.GDMuscleCarYellowObjects1= [];
gdjs._49Code.GDMuscleCarYellowObjects2= [];
gdjs._49Code.GDSedanGreyObjects1= [];
gdjs._49Code.GDSedanGreyObjects2= [];
gdjs._49Code.GDSuvTanObjects1= [];
gdjs._49Code.GDSuvTanObjects2= [];
gdjs._49Code.GDSportsCarGreyObjects1= [];
gdjs._49Code.GDSportsCarGreyObjects2= [];
gdjs._49Code.GDSemiTruckObjects1= [];
gdjs._49Code.GDSemiTruckObjects2= [];
gdjs._49Code.GDSportsCarOrangeObjects1= [];
gdjs._49Code.GDSportsCarOrangeObjects2= [];
gdjs._49Code.GDSportsCarRedObjects1= [];
gdjs._49Code.GDSportsCarRedObjects2= [];
gdjs._49Code.GDSportsCarLightYellowObjects1= [];
gdjs._49Code.GDSportsCarLightYellowObjects2= [];
gdjs._49Code.GDTankObjects1= [];
gdjs._49Code.GDTankObjects2= [];
gdjs._49Code.GDSportsCarYellowObjects1= [];
gdjs._49Code.GDSportsCarYellowObjects2= [];
gdjs._49Code.GDTruckObjects1= [];
gdjs._49Code.GDTruckObjects2= [];
gdjs._49Code.GDWoodenCarObjects1= [];
gdjs._49Code.GDWoodenCarObjects2= [];
gdjs._49Code.GDHomeObjects1= [];
gdjs._49Code.GDHomeObjects2= [];


gdjs._49Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs._49Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._49Code.GDStatueObjects1.length = 0;
gdjs._49Code.GDStatueObjects2.length = 0;
gdjs._49Code.GDWiderectanglestoneObjects1.length = 0;
gdjs._49Code.GDWiderectanglestoneObjects2.length = 0;
gdjs._49Code.GDPlayerBulletObjects1.length = 0;
gdjs._49Code.GDPlayerBulletObjects2.length = 0;
gdjs._49Code.GDTilesetPiece55Objects1.length = 0;
gdjs._49Code.GDTilesetPiece55Objects2.length = 0;
gdjs._49Code.GDpolicecarObjects1.length = 0;
gdjs._49Code.GDpolicecarObjects2.length = 0;
gdjs._49Code.GDEnemyBulletObjects1.length = 0;
gdjs._49Code.GDEnemyBulletObjects2.length = 0;
gdjs._49Code.GDGameOverObjects1.length = 0;
gdjs._49Code.GDGameOverObjects2.length = 0;
gdjs._49Code.GDTutorialTextObjects1.length = 0;
gdjs._49Code.GDTutorialTextObjects2.length = 0;
gdjs._49Code.GDScoreObjects1.length = 0;
gdjs._49Code.GDScoreObjects2.length = 0;
gdjs._49Code.GDHighScoreObjects1.length = 0;
gdjs._49Code.GDHighScoreObjects2.length = 0;
gdjs._49Code.GDBluePowerupObjects1.length = 0;
gdjs._49Code.GDBluePowerupObjects2.length = 0;
gdjs._49Code.GDMetalRedBarObjects1.length = 0;
gdjs._49Code.GDMetalRedBarObjects2.length = 0;
gdjs._49Code.GDHitObjects1.length = 0;
gdjs._49Code.GDHitObjects2.length = 0;
gdjs._49Code.GDClickPointObjects1.length = 0;
gdjs._49Code.GDClickPointObjects2.length = 0;
gdjs._49Code.GDRoadObjects1.length = 0;
gdjs._49Code.GDRoadObjects2.length = 0;
gdjs._49Code.GDRoadLineObjects1.length = 0;
gdjs._49Code.GDRoadLineObjects2.length = 0;
gdjs._49Code.GDGrassObjects1.length = 0;
gdjs._49Code.GDGrassObjects2.length = 0;
gdjs._49Code.GDAmphibiousCarYellowObjects1.length = 0;
gdjs._49Code.GDAmphibiousCarYellowObjects2.length = 0;
gdjs._49Code.GDCarRedObjects1.length = 0;
gdjs._49Code.GDCarRedObjects2.length = 0;
gdjs._49Code.GDConvertiblePurpleObjects1.length = 0;
gdjs._49Code.GDConvertiblePurpleObjects2.length = 0;
gdjs._49Code.GDConvertibleBlueObjects1.length = 0;
gdjs._49Code.GDConvertibleBlueObjects2.length = 0;
gdjs._49Code.GDAmphibiousCarBlueObjects1.length = 0;
gdjs._49Code.GDAmphibiousCarBlueObjects2.length = 0;
gdjs._49Code.GDCarBlueObjects1.length = 0;
gdjs._49Code.GDCarBlueObjects2.length = 0;
gdjs._49Code.GDCoupeBlueObjects1.length = 0;
gdjs._49Code.GDCoupeBlueObjects2.length = 0;
gdjs._49Code.GDF1CarLightBlueObjects1.length = 0;
gdjs._49Code.GDF1CarLightBlueObjects2.length = 0;
gdjs._49Code.GDF1CarBrownObjects1.length = 0;
gdjs._49Code.GDF1CarBrownObjects2.length = 0;
gdjs._49Code.GDF1CarRedObjects1.length = 0;
gdjs._49Code.GDF1CarRedObjects2.length = 0;
gdjs._49Code.GDCoupeYellowObjects1.length = 0;
gdjs._49Code.GDCoupeYellowObjects2.length = 0;
gdjs._49Code.GDJeepBriteGreenObjects1.length = 0;
gdjs._49Code.GDJeepBriteGreenObjects2.length = 0;
gdjs._49Code.GDFuelSemiTruckObjects1.length = 0;
gdjs._49Code.GDFuelSemiTruckObjects2.length = 0;
gdjs._49Code.GDJeepGreenObjects1.length = 0;
gdjs._49Code.GDJeepGreenObjects2.length = 0;
gdjs._49Code.GDMuscleCarBlueObjects1.length = 0;
gdjs._49Code.GDMuscleCarBlueObjects2.length = 0;
gdjs._49Code.GDSedanGreenObjects1.length = 0;
gdjs._49Code.GDSedanGreenObjects2.length = 0;
gdjs._49Code.GDMuscleCarYellowObjects1.length = 0;
gdjs._49Code.GDMuscleCarYellowObjects2.length = 0;
gdjs._49Code.GDSedanGreyObjects1.length = 0;
gdjs._49Code.GDSedanGreyObjects2.length = 0;
gdjs._49Code.GDSuvTanObjects1.length = 0;
gdjs._49Code.GDSuvTanObjects2.length = 0;
gdjs._49Code.GDSportsCarGreyObjects1.length = 0;
gdjs._49Code.GDSportsCarGreyObjects2.length = 0;
gdjs._49Code.GDSemiTruckObjects1.length = 0;
gdjs._49Code.GDSemiTruckObjects2.length = 0;
gdjs._49Code.GDSportsCarOrangeObjects1.length = 0;
gdjs._49Code.GDSportsCarOrangeObjects2.length = 0;
gdjs._49Code.GDSportsCarRedObjects1.length = 0;
gdjs._49Code.GDSportsCarRedObjects2.length = 0;
gdjs._49Code.GDSportsCarLightYellowObjects1.length = 0;
gdjs._49Code.GDSportsCarLightYellowObjects2.length = 0;
gdjs._49Code.GDTankObjects1.length = 0;
gdjs._49Code.GDTankObjects2.length = 0;
gdjs._49Code.GDSportsCarYellowObjects1.length = 0;
gdjs._49Code.GDSportsCarYellowObjects2.length = 0;
gdjs._49Code.GDTruckObjects1.length = 0;
gdjs._49Code.GDTruckObjects2.length = 0;
gdjs._49Code.GDWoodenCarObjects1.length = 0;
gdjs._49Code.GDWoodenCarObjects2.length = 0;
gdjs._49Code.GDHomeObjects1.length = 0;
gdjs._49Code.GDHomeObjects2.length = 0;

gdjs._49Code.eventsList0(runtimeScene);

return;

}

gdjs['_49Code'] = gdjs._49Code;
