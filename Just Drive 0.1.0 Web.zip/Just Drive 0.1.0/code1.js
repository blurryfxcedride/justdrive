gdjs.MenuCode = {};
gdjs.MenuCode.GDConvertibleBlueObjects1= [];
gdjs.MenuCode.GDConvertibleBlueObjects2= [];
gdjs.MenuCode.GDAmphibiousCarBlueObjects1= [];
gdjs.MenuCode.GDAmphibiousCarBlueObjects2= [];
gdjs.MenuCode.GDCarBlueObjects1= [];
gdjs.MenuCode.GDCarBlueObjects2= [];
gdjs.MenuCode.GDCarRedObjects1= [];
gdjs.MenuCode.GDCarRedObjects2= [];
gdjs.MenuCode.GDAmphibiousCarYellowObjects1= [];
gdjs.MenuCode.GDAmphibiousCarYellowObjects2= [];
gdjs.MenuCode.GDConvertiblePurpleObjects1= [];
gdjs.MenuCode.GDConvertiblePurpleObjects2= [];
gdjs.MenuCode.GDCoupeBlueObjects1= [];
gdjs.MenuCode.GDCoupeBlueObjects2= [];
gdjs.MenuCode.GDCoupeYellowObjects1= [];
gdjs.MenuCode.GDCoupeYellowObjects2= [];
gdjs.MenuCode.GDF1CarRedObjects1= [];
gdjs.MenuCode.GDF1CarRedObjects2= [];
gdjs.MenuCode.GDFuelSemiTruckObjects1= [];
gdjs.MenuCode.GDFuelSemiTruckObjects2= [];
gdjs.MenuCode.GDF1CarBrownObjects1= [];
gdjs.MenuCode.GDF1CarBrownObjects2= [];
gdjs.MenuCode.GDF1CarLightBlueObjects1= [];
gdjs.MenuCode.GDF1CarLightBlueObjects2= [];
gdjs.MenuCode.GDJeepBriteGreenObjects1= [];
gdjs.MenuCode.GDJeepBriteGreenObjects2= [];
gdjs.MenuCode.GDJeepGreenObjects1= [];
gdjs.MenuCode.GDJeepGreenObjects2= [];
gdjs.MenuCode.GDSuvTanObjects1= [];
gdjs.MenuCode.GDSuvTanObjects2= [];
gdjs.MenuCode.GDSedanGreenObjects1= [];
gdjs.MenuCode.GDSedanGreenObjects2= [];
gdjs.MenuCode.GDMuscleCarYellowObjects1= [];
gdjs.MenuCode.GDMuscleCarYellowObjects2= [];
gdjs.MenuCode.GDMuscleCarBlueObjects1= [];
gdjs.MenuCode.GDMuscleCarBlueObjects2= [];
gdjs.MenuCode.GDSedanGreyObjects1= [];
gdjs.MenuCode.GDSedanGreyObjects2= [];
gdjs.MenuCode.GDSportsCarGreyObjects1= [];
gdjs.MenuCode.GDSportsCarGreyObjects2= [];
gdjs.MenuCode.GDSemiTruckObjects1= [];
gdjs.MenuCode.GDSemiTruckObjects2= [];
gdjs.MenuCode.GDSportsCarLightYellowObjects1= [];
gdjs.MenuCode.GDSportsCarLightYellowObjects2= [];
gdjs.MenuCode.GDSportsCarYellowObjects1= [];
gdjs.MenuCode.GDSportsCarYellowObjects2= [];
gdjs.MenuCode.GDSportsCarRedObjects1= [];
gdjs.MenuCode.GDSportsCarRedObjects2= [];
gdjs.MenuCode.GDSportsCarOrangeObjects1= [];
gdjs.MenuCode.GDSportsCarOrangeObjects2= [];
gdjs.MenuCode.GDTankObjects1= [];
gdjs.MenuCode.GDTankObjects2= [];
gdjs.MenuCode.GDTruckObjects1= [];
gdjs.MenuCode.GDTruckObjects2= [];
gdjs.MenuCode.GDWoodenCarObjects1= [];
gdjs.MenuCode.GDWoodenCarObjects2= [];
gdjs.MenuCode.GDGreyButtonObjects1= [];
gdjs.MenuCode.GDGreyButtonObjects2= [];
gdjs.MenuCode.GDsportsObjects1= [];
gdjs.MenuCode.GDsportsObjects2= [];
gdjs.MenuCode.GDjeepObjects1= [];
gdjs.MenuCode.GDjeepObjects2= [];
gdjs.MenuCode.GDJustDriveObjects1= [];
gdjs.MenuCode.GDJustDriveObjects2= [];
gdjs.MenuCode.GDControlsObjects1= [];
gdjs.MenuCode.GDControlsObjects2= [];
gdjs.MenuCode.GDSettingsObjects1= [];
gdjs.MenuCode.GDSettingsObjects2= [];
gdjs.MenuCode.GDGameJoltObjects1= [];
gdjs.MenuCode.GDGameJoltObjects2= [];


gdjs.MenuCode.asyncCallback17507236 = function (runtimeScene, asyncObjectsList) {
}
gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__GamejoltAPI__AddTrophies.func(runtimeScene, "197497", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.MenuCode.asyncCallback17507236(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MenuCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.MenuCode.GDGreyButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDGreyButtonObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDGreyButtonObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDGreyButtonObjects1[k] = gdjs.MenuCode.GDGreyButtonObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDGreyButtonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.MenuCode.GDGreyButtonObjects1 */
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.MenuCode.GDGreyButtonObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MenuCode.GDGreyButtonObjects1[0].getVariables()).getFromIndex(0)))), false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("sports"), gdjs.MenuCode.GDsportsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDsportsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDsportsObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDsportsObjects1[k] = gdjs.MenuCode.GDsportsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDsportsObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.MenuCode.GDGreyButtonObjects1);
{for(var i = 0, len = gdjs.MenuCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDGreyButtonObjects1[i].returnVariable(gdjs.MenuCode.GDGreyButtonObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("jeep"), gdjs.MenuCode.GDjeepObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDjeepObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDjeepObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDjeepObjects1[k] = gdjs.MenuCode.GDjeepObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDjeepObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.MenuCode.GDGreyButtonObjects1);
{for(var i = 0, len = gdjs.MenuCode.GDGreyButtonObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDGreyButtonObjects1[i].returnVariable(gdjs.MenuCode.GDGreyButtonObjects1[i].getVariables().getFromIndex(0)).setNumber(2);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Settings"), gdjs.MenuCode.GDSettingsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDSettingsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDSettingsObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDSettingsObjects1[k] = gdjs.MenuCode.GDSettingsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDSettingsObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Settings", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Controls"), gdjs.MenuCode.GDControlsObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDControlsObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDControlsObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDControlsObjects1[k] = gdjs.MenuCode.GDControlsObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDControlsObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Controls", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GreyButton"), gdjs.MenuCode.GDGreyButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDGreyButtonObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDGreyButtonObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDGreyButtonObjects1[k] = gdjs.MenuCode.GDGreyButtonObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDGreyButtonObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.MenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GameJolt"), gdjs.MenuCode.GDGameJoltObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDGameJoltObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDGameJoltObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDGameJoltObjects1[k] = gdjs.MenuCode.GDGameJoltObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDGameJoltObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameJolt", false);
}}

}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDConvertibleBlueObjects1.length = 0;
gdjs.MenuCode.GDConvertibleBlueObjects2.length = 0;
gdjs.MenuCode.GDAmphibiousCarBlueObjects1.length = 0;
gdjs.MenuCode.GDAmphibiousCarBlueObjects2.length = 0;
gdjs.MenuCode.GDCarBlueObjects1.length = 0;
gdjs.MenuCode.GDCarBlueObjects2.length = 0;
gdjs.MenuCode.GDCarRedObjects1.length = 0;
gdjs.MenuCode.GDCarRedObjects2.length = 0;
gdjs.MenuCode.GDAmphibiousCarYellowObjects1.length = 0;
gdjs.MenuCode.GDAmphibiousCarYellowObjects2.length = 0;
gdjs.MenuCode.GDConvertiblePurpleObjects1.length = 0;
gdjs.MenuCode.GDConvertiblePurpleObjects2.length = 0;
gdjs.MenuCode.GDCoupeBlueObjects1.length = 0;
gdjs.MenuCode.GDCoupeBlueObjects2.length = 0;
gdjs.MenuCode.GDCoupeYellowObjects1.length = 0;
gdjs.MenuCode.GDCoupeYellowObjects2.length = 0;
gdjs.MenuCode.GDF1CarRedObjects1.length = 0;
gdjs.MenuCode.GDF1CarRedObjects2.length = 0;
gdjs.MenuCode.GDFuelSemiTruckObjects1.length = 0;
gdjs.MenuCode.GDFuelSemiTruckObjects2.length = 0;
gdjs.MenuCode.GDF1CarBrownObjects1.length = 0;
gdjs.MenuCode.GDF1CarBrownObjects2.length = 0;
gdjs.MenuCode.GDF1CarLightBlueObjects1.length = 0;
gdjs.MenuCode.GDF1CarLightBlueObjects2.length = 0;
gdjs.MenuCode.GDJeepBriteGreenObjects1.length = 0;
gdjs.MenuCode.GDJeepBriteGreenObjects2.length = 0;
gdjs.MenuCode.GDJeepGreenObjects1.length = 0;
gdjs.MenuCode.GDJeepGreenObjects2.length = 0;
gdjs.MenuCode.GDSuvTanObjects1.length = 0;
gdjs.MenuCode.GDSuvTanObjects2.length = 0;
gdjs.MenuCode.GDSedanGreenObjects1.length = 0;
gdjs.MenuCode.GDSedanGreenObjects2.length = 0;
gdjs.MenuCode.GDMuscleCarYellowObjects1.length = 0;
gdjs.MenuCode.GDMuscleCarYellowObjects2.length = 0;
gdjs.MenuCode.GDMuscleCarBlueObjects1.length = 0;
gdjs.MenuCode.GDMuscleCarBlueObjects2.length = 0;
gdjs.MenuCode.GDSedanGreyObjects1.length = 0;
gdjs.MenuCode.GDSedanGreyObjects2.length = 0;
gdjs.MenuCode.GDSportsCarGreyObjects1.length = 0;
gdjs.MenuCode.GDSportsCarGreyObjects2.length = 0;
gdjs.MenuCode.GDSemiTruckObjects1.length = 0;
gdjs.MenuCode.GDSemiTruckObjects2.length = 0;
gdjs.MenuCode.GDSportsCarLightYellowObjects1.length = 0;
gdjs.MenuCode.GDSportsCarLightYellowObjects2.length = 0;
gdjs.MenuCode.GDSportsCarYellowObjects1.length = 0;
gdjs.MenuCode.GDSportsCarYellowObjects2.length = 0;
gdjs.MenuCode.GDSportsCarRedObjects1.length = 0;
gdjs.MenuCode.GDSportsCarRedObjects2.length = 0;
gdjs.MenuCode.GDSportsCarOrangeObjects1.length = 0;
gdjs.MenuCode.GDSportsCarOrangeObjects2.length = 0;
gdjs.MenuCode.GDTankObjects1.length = 0;
gdjs.MenuCode.GDTankObjects2.length = 0;
gdjs.MenuCode.GDTruckObjects1.length = 0;
gdjs.MenuCode.GDTruckObjects2.length = 0;
gdjs.MenuCode.GDWoodenCarObjects1.length = 0;
gdjs.MenuCode.GDWoodenCarObjects2.length = 0;
gdjs.MenuCode.GDGreyButtonObjects1.length = 0;
gdjs.MenuCode.GDGreyButtonObjects2.length = 0;
gdjs.MenuCode.GDsportsObjects1.length = 0;
gdjs.MenuCode.GDsportsObjects2.length = 0;
gdjs.MenuCode.GDjeepObjects1.length = 0;
gdjs.MenuCode.GDjeepObjects2.length = 0;
gdjs.MenuCode.GDJustDriveObjects1.length = 0;
gdjs.MenuCode.GDJustDriveObjects2.length = 0;
gdjs.MenuCode.GDControlsObjects1.length = 0;
gdjs.MenuCode.GDControlsObjects2.length = 0;
gdjs.MenuCode.GDSettingsObjects1.length = 0;
gdjs.MenuCode.GDSettingsObjects2.length = 0;
gdjs.MenuCode.GDGameJoltObjects1.length = 0;
gdjs.MenuCode.GDGameJoltObjects2.length = 0;

gdjs.MenuCode.eventsList1(runtimeScene);

return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
