gdjs.LoadingCode = {};
gdjs.LoadingCode.GDNewSpriteObjects1= [];
gdjs.LoadingCode.GDNewSpriteObjects2= [];
gdjs.LoadingCode.GDStartObjects1= [];
gdjs.LoadingCode.GDStartObjects2= [];
gdjs.LoadingCode.GDBanditoObjects1= [];
gdjs.LoadingCode.GDBanditoObjects2= [];


gdjs.LoadingCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}{gdjs.evtsExt__GamejoltAPI__RegisterGame.func(runtimeScene, "817250", "1038f327b43e5a1932d3971177b0cdb7", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};

gdjs.LoadingCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.LoadingCode.GDNewSpriteObjects1.length = 0;
gdjs.LoadingCode.GDNewSpriteObjects2.length = 0;
gdjs.LoadingCode.GDStartObjects1.length = 0;
gdjs.LoadingCode.GDStartObjects2.length = 0;
gdjs.LoadingCode.GDBanditoObjects1.length = 0;
gdjs.LoadingCode.GDBanditoObjects2.length = 0;

gdjs.LoadingCode.eventsList0(runtimeScene);

return;

}

gdjs['LoadingCode'] = gdjs.LoadingCode;
