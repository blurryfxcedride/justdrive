gdjs.ControlsCode = {};
gdjs.ControlsCode.GDNewTextObjects1= [];
gdjs.ControlsCode.GDNewTextObjects2= [];


gdjs.ControlsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.ControlsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ControlsCode.GDNewTextObjects1.length = 0;
gdjs.ControlsCode.GDNewTextObjects2.length = 0;

gdjs.ControlsCode.eventsList0(runtimeScene);

return;

}

gdjs['ControlsCode'] = gdjs.ControlsCode;
