gdjs.GameJoltCode = {};
gdjs.GameJoltCode.GDUsernameObjects1= [];
gdjs.GameJoltCode.GDUsernameObjects2= [];
gdjs.GameJoltCode.GDPasswordObjects1= [];
gdjs.GameJoltCode.GDPasswordObjects2= [];
gdjs.GameJoltCode.GDLoginObjects1= [];
gdjs.GameJoltCode.GDLoginObjects2= [];
gdjs.GameJoltCode.GDUSaveObjects1= [];
gdjs.GameJoltCode.GDUSaveObjects2= [];
gdjs.GameJoltCode.GDPSaveObjects1= [];
gdjs.GameJoltCode.GDPSaveObjects2= [];
gdjs.GameJoltCode.GDComingSoonObjects1= [];
gdjs.GameJoltCode.GDComingSoonObjects2= [];
gdjs.GameJoltCode.GDGreyButtonObjects1= [];
gdjs.GameJoltCode.GDGreyButtonObjects2= [];
gdjs.GameJoltCode.GDTextheheheObjects1= [];
gdjs.GameJoltCode.GDTextheheheObjects2= [];


gdjs.GameJoltCode.asyncCallback16712868 = function (runtimeScene, asyncObjectsList) {
}
gdjs.GameJoltCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__GamejoltAPI__AuthenticateUser.func(runtimeScene, "username", "password", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)), (runtimeScene) => (gdjs.GameJoltCode.asyncCallback16712868(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameJoltCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Login"), gdjs.GameJoltCode.GDLoginObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameJoltCode.GDLoginObjects1.length;i<l;++i) {
    if ( gdjs.GameJoltCode.GDLoginObjects1[i].IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.GameJoltCode.GDLoginObjects1[k] = gdjs.GameJoltCode.GDLoginObjects1[i];
        ++k;
    }
}
gdjs.GameJoltCode.GDLoginObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Password"), gdjs.GameJoltCode.GDPasswordObjects1);
gdjs.copyArray(runtimeScene.getObjects("Username"), gdjs.GameJoltCode.GDUsernameObjects1);
{for(var i = 0, len = gdjs.GameJoltCode.GDUsernameObjects1.length ;i < len;++i) {
    gdjs.GameJoltCode.GDUsernameObjects1[i].setInputType("username");
}
}{for(var i = 0, len = gdjs.GameJoltCode.GDPasswordObjects1.length ;i < len;++i) {
    gdjs.GameJoltCode.GDPasswordObjects1[i].setInputType("password");
}
}
{ //Subevents
gdjs.GameJoltCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.GameJoltCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameJoltCode.GDUsernameObjects1.length = 0;
gdjs.GameJoltCode.GDUsernameObjects2.length = 0;
gdjs.GameJoltCode.GDPasswordObjects1.length = 0;
gdjs.GameJoltCode.GDPasswordObjects2.length = 0;
gdjs.GameJoltCode.GDLoginObjects1.length = 0;
gdjs.GameJoltCode.GDLoginObjects2.length = 0;
gdjs.GameJoltCode.GDUSaveObjects1.length = 0;
gdjs.GameJoltCode.GDUSaveObjects2.length = 0;
gdjs.GameJoltCode.GDPSaveObjects1.length = 0;
gdjs.GameJoltCode.GDPSaveObjects2.length = 0;
gdjs.GameJoltCode.GDComingSoonObjects1.length = 0;
gdjs.GameJoltCode.GDComingSoonObjects2.length = 0;
gdjs.GameJoltCode.GDGreyButtonObjects1.length = 0;
gdjs.GameJoltCode.GDGreyButtonObjects2.length = 0;
gdjs.GameJoltCode.GDTextheheheObjects1.length = 0;
gdjs.GameJoltCode.GDTextheheheObjects2.length = 0;

gdjs.GameJoltCode.eventsList1(runtimeScene);

return;

}

gdjs['GameJoltCode'] = gdjs.GameJoltCode;
