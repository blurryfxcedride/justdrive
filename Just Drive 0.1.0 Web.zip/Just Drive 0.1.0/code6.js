gdjs.SettingsCode = {};
gdjs.SettingsCode.GDSmallPlasticGreenRoundSliderObjects1= [];
gdjs.SettingsCode.GDSmallPlasticGreenRoundSliderObjects2= [];
gdjs.SettingsCode.GDSquareWhiteSliderObjects1= [];
gdjs.SettingsCode.GDSquareWhiteSliderObjects2= [];
gdjs.SettingsCode.GDSmallGreenPlasticRoundSwitchObjects1= [];
gdjs.SettingsCode.GDSmallGreenPlasticRoundSwitchObjects2= [];
gdjs.SettingsCode.GDSmallPlasticGreenSquareSliderObjects1= [];
gdjs.SettingsCode.GDSmallPlasticGreenSquareSliderObjects2= [];
gdjs.SettingsCode.GDSquareBlueSliderObjects1= [];
gdjs.SettingsCode.GDSquareBlueSliderObjects2= [];
gdjs.SettingsCode.GDSquareGreenSliderObjects1= [];
gdjs.SettingsCode.GDSquareGreenSliderObjects2= [];
gdjs.SettingsCode.GDSmallGreenPlasticRoundToggleObjects1= [];
gdjs.SettingsCode.GDSmallGreenPlasticRoundToggleObjects2= [];
gdjs.SettingsCode.GDGoldRoundToggleObjects1= [];
gdjs.SettingsCode.GDGoldRoundToggleObjects2= [];
gdjs.SettingsCode.GDSmallGreenPlasticSquareToggleObjects1= [];
gdjs.SettingsCode.GDSmallGreenPlasticSquareToggleObjects2= [];
gdjs.SettingsCode.GDSquareWhiteToggleObjects1= [];
gdjs.SettingsCode.GDSquareWhiteToggleObjects2= [];
gdjs.SettingsCode.GDSquareGreenToggleObjects1= [];
gdjs.SettingsCode.GDSquareGreenToggleObjects2= [];
gdjs.SettingsCode.GDGoldSquareToggleObjects1= [];
gdjs.SettingsCode.GDGoldSquareToggleObjects2= [];
gdjs.SettingsCode.GDSquareBlueToggleObjects1= [];
gdjs.SettingsCode.GDSquareBlueToggleObjects2= [];


gdjs.SettingsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs.SettingsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SettingsCode.GDSmallPlasticGreenRoundSliderObjects1.length = 0;
gdjs.SettingsCode.GDSmallPlasticGreenRoundSliderObjects2.length = 0;
gdjs.SettingsCode.GDSquareWhiteSliderObjects1.length = 0;
gdjs.SettingsCode.GDSquareWhiteSliderObjects2.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticRoundSwitchObjects1.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticRoundSwitchObjects2.length = 0;
gdjs.SettingsCode.GDSmallPlasticGreenSquareSliderObjects1.length = 0;
gdjs.SettingsCode.GDSmallPlasticGreenSquareSliderObjects2.length = 0;
gdjs.SettingsCode.GDSquareBlueSliderObjects1.length = 0;
gdjs.SettingsCode.GDSquareBlueSliderObjects2.length = 0;
gdjs.SettingsCode.GDSquareGreenSliderObjects1.length = 0;
gdjs.SettingsCode.GDSquareGreenSliderObjects2.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticRoundToggleObjects1.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticRoundToggleObjects2.length = 0;
gdjs.SettingsCode.GDGoldRoundToggleObjects1.length = 0;
gdjs.SettingsCode.GDGoldRoundToggleObjects2.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticSquareToggleObjects1.length = 0;
gdjs.SettingsCode.GDSmallGreenPlasticSquareToggleObjects2.length = 0;
gdjs.SettingsCode.GDSquareWhiteToggleObjects1.length = 0;
gdjs.SettingsCode.GDSquareWhiteToggleObjects2.length = 0;
gdjs.SettingsCode.GDSquareGreenToggleObjects1.length = 0;
gdjs.SettingsCode.GDSquareGreenToggleObjects2.length = 0;
gdjs.SettingsCode.GDGoldSquareToggleObjects1.length = 0;
gdjs.SettingsCode.GDGoldSquareToggleObjects2.length = 0;
gdjs.SettingsCode.GDSquareBlueToggleObjects1.length = 0;
gdjs.SettingsCode.GDSquareBlueToggleObjects2.length = 0;

gdjs.SettingsCode.eventsList0(runtimeScene);

return;

}

gdjs['SettingsCode'] = gdjs.SettingsCode;
