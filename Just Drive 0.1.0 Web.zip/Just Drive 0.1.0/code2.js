gdjs._50Code = {};
gdjs._50Code.GDStatueObjects1= [];
gdjs._50Code.GDStatueObjects2= [];
gdjs._50Code.GDWiderectanglestoneObjects1= [];
gdjs._50Code.GDWiderectanglestoneObjects2= [];
gdjs._50Code.GDPlayerBulletObjects1= [];
gdjs._50Code.GDPlayerBulletObjects2= [];
gdjs._50Code.GDTilesetPiece55Objects1= [];
gdjs._50Code.GDTilesetPiece55Objects2= [];
gdjs._50Code.GDpolicecarObjects1= [];
gdjs._50Code.GDpolicecarObjects2= [];
gdjs._50Code.GDEnemyBulletObjects1= [];
gdjs._50Code.GDEnemyBulletObjects2= [];
gdjs._50Code.GDGameOverObjects1= [];
gdjs._50Code.GDGameOverObjects2= [];
gdjs._50Code.GDTutorialTextObjects1= [];
gdjs._50Code.GDTutorialTextObjects2= [];
gdjs._50Code.GDScoreObjects1= [];
gdjs._50Code.GDScoreObjects2= [];
gdjs._50Code.GDHighScoreObjects1= [];
gdjs._50Code.GDHighScoreObjects2= [];
gdjs._50Code.GDBluePowerupObjects1= [];
gdjs._50Code.GDBluePowerupObjects2= [];
gdjs._50Code.GDMetalRedBarObjects1= [];
gdjs._50Code.GDMetalRedBarObjects2= [];
gdjs._50Code.GDHitObjects1= [];
gdjs._50Code.GDHitObjects2= [];
gdjs._50Code.GDClickPointObjects1= [];
gdjs._50Code.GDClickPointObjects2= [];
gdjs._50Code.GDRoadObjects1= [];
gdjs._50Code.GDRoadObjects2= [];
gdjs._50Code.GDHalfObjects1= [];
gdjs._50Code.GDHalfObjects2= [];
gdjs._50Code.GDRoadLineObjects1= [];
gdjs._50Code.GDRoadLineObjects2= [];
gdjs._50Code.GDGrassObjects1= [];
gdjs._50Code.GDGrassObjects2= [];
gdjs._50Code.GDAmphibiousCarYellowObjects1= [];
gdjs._50Code.GDAmphibiousCarYellowObjects2= [];
gdjs._50Code.GDCarRedObjects1= [];
gdjs._50Code.GDCarRedObjects2= [];
gdjs._50Code.GDConvertiblePurpleObjects1= [];
gdjs._50Code.GDConvertiblePurpleObjects2= [];
gdjs._50Code.GDConvertibleBlueObjects1= [];
gdjs._50Code.GDConvertibleBlueObjects2= [];
gdjs._50Code.GDAmphibiousCarBlueObjects1= [];
gdjs._50Code.GDAmphibiousCarBlueObjects2= [];
gdjs._50Code.GDCarBlueObjects1= [];
gdjs._50Code.GDCarBlueObjects2= [];
gdjs._50Code.GDCoupeBlueObjects1= [];
gdjs._50Code.GDCoupeBlueObjects2= [];
gdjs._50Code.GDF1CarLightBlueObjects1= [];
gdjs._50Code.GDF1CarLightBlueObjects2= [];
gdjs._50Code.GDF1CarBrownObjects1= [];
gdjs._50Code.GDF1CarBrownObjects2= [];
gdjs._50Code.GDF1CarRedObjects1= [];
gdjs._50Code.GDF1CarRedObjects2= [];
gdjs._50Code.GDCoupeYellowObjects1= [];
gdjs._50Code.GDCoupeYellowObjects2= [];
gdjs._50Code.GDJeepBriteGreenObjects1= [];
gdjs._50Code.GDJeepBriteGreenObjects2= [];
gdjs._50Code.GDFuelSemiTruckObjects1= [];
gdjs._50Code.GDFuelSemiTruckObjects2= [];
gdjs._50Code.GDJeepGreenObjects1= [];
gdjs._50Code.GDJeepGreenObjects2= [];
gdjs._50Code.GDMuscleCarBlueObjects1= [];
gdjs._50Code.GDMuscleCarBlueObjects2= [];
gdjs._50Code.GDSedanGreenObjects1= [];
gdjs._50Code.GDSedanGreenObjects2= [];
gdjs._50Code.GDMuscleCarYellowObjects1= [];
gdjs._50Code.GDMuscleCarYellowObjects2= [];
gdjs._50Code.GDSedanGreyObjects1= [];
gdjs._50Code.GDSedanGreyObjects2= [];
gdjs._50Code.GDSuvTanObjects1= [];
gdjs._50Code.GDSuvTanObjects2= [];
gdjs._50Code.GDSportsCarGreyObjects1= [];
gdjs._50Code.GDSportsCarGreyObjects2= [];
gdjs._50Code.GDSemiTruckObjects1= [];
gdjs._50Code.GDSemiTruckObjects2= [];
gdjs._50Code.GDSportsCarOrangeObjects1= [];
gdjs._50Code.GDSportsCarOrangeObjects2= [];
gdjs._50Code.GDSportsCarRedObjects1= [];
gdjs._50Code.GDSportsCarRedObjects2= [];
gdjs._50Code.GDSportsCarLightYellowObjects1= [];
gdjs._50Code.GDSportsCarLightYellowObjects2= [];
gdjs._50Code.GDTankObjects1= [];
gdjs._50Code.GDTankObjects2= [];
gdjs._50Code.GDSportsCarYellowObjects1= [];
gdjs._50Code.GDSportsCarYellowObjects2= [];
gdjs._50Code.GDTruckObjects1= [];
gdjs._50Code.GDTruckObjects2= [];
gdjs._50Code.GDWoodenCarObjects1= [];
gdjs._50Code.GDWoodenCarObjects2= [];
gdjs._50Code.GDBush2Objects1= [];
gdjs._50Code.GDBush2Objects2= [];
gdjs._50Code.GDBush1Objects1= [];
gdjs._50Code.GDBush1Objects2= [];
gdjs._50Code.GDBush3Objects1= [];
gdjs._50Code.GDBush3Objects2= [];
gdjs._50Code.GDHomeObjects1= [];
gdjs._50Code.GDHomeObjects2= [];
gdjs._50Code.GDEdgeObjects1= [];
gdjs._50Code.GDEdgeObjects2= [];


gdjs._50Code.mapOfGDgdjs_46_9550Code_46GDJeepGreenObjects1Objects = Hashtable.newFrom({"JeepGreen": gdjs._50Code.GDJeepGreenObjects1});
gdjs._50Code.mapOfGDgdjs_46_9550Code_46GDEdgeObjects1Objects = Hashtable.newFrom({"Edge": gdjs._50Code.GDEdgeObjects1});
gdjs._50Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Edge"), gdjs._50Code.GDEdgeObjects1);
gdjs.copyArray(runtimeScene.getObjects("JeepGreen"), gdjs._50Code.GDJeepGreenObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._50Code.mapOfGDgdjs_46_9550Code_46GDJeepGreenObjects1Objects, gdjs._50Code.mapOfGDgdjs_46_9550Code_46GDEdgeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
}

}


};

gdjs._50Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._50Code.GDStatueObjects1.length = 0;
gdjs._50Code.GDStatueObjects2.length = 0;
gdjs._50Code.GDWiderectanglestoneObjects1.length = 0;
gdjs._50Code.GDWiderectanglestoneObjects2.length = 0;
gdjs._50Code.GDPlayerBulletObjects1.length = 0;
gdjs._50Code.GDPlayerBulletObjects2.length = 0;
gdjs._50Code.GDTilesetPiece55Objects1.length = 0;
gdjs._50Code.GDTilesetPiece55Objects2.length = 0;
gdjs._50Code.GDpolicecarObjects1.length = 0;
gdjs._50Code.GDpolicecarObjects2.length = 0;
gdjs._50Code.GDEnemyBulletObjects1.length = 0;
gdjs._50Code.GDEnemyBulletObjects2.length = 0;
gdjs._50Code.GDGameOverObjects1.length = 0;
gdjs._50Code.GDGameOverObjects2.length = 0;
gdjs._50Code.GDTutorialTextObjects1.length = 0;
gdjs._50Code.GDTutorialTextObjects2.length = 0;
gdjs._50Code.GDScoreObjects1.length = 0;
gdjs._50Code.GDScoreObjects2.length = 0;
gdjs._50Code.GDHighScoreObjects1.length = 0;
gdjs._50Code.GDHighScoreObjects2.length = 0;
gdjs._50Code.GDBluePowerupObjects1.length = 0;
gdjs._50Code.GDBluePowerupObjects2.length = 0;
gdjs._50Code.GDMetalRedBarObjects1.length = 0;
gdjs._50Code.GDMetalRedBarObjects2.length = 0;
gdjs._50Code.GDHitObjects1.length = 0;
gdjs._50Code.GDHitObjects2.length = 0;
gdjs._50Code.GDClickPointObjects1.length = 0;
gdjs._50Code.GDClickPointObjects2.length = 0;
gdjs._50Code.GDRoadObjects1.length = 0;
gdjs._50Code.GDRoadObjects2.length = 0;
gdjs._50Code.GDHalfObjects1.length = 0;
gdjs._50Code.GDHalfObjects2.length = 0;
gdjs._50Code.GDRoadLineObjects1.length = 0;
gdjs._50Code.GDRoadLineObjects2.length = 0;
gdjs._50Code.GDGrassObjects1.length = 0;
gdjs._50Code.GDGrassObjects2.length = 0;
gdjs._50Code.GDAmphibiousCarYellowObjects1.length = 0;
gdjs._50Code.GDAmphibiousCarYellowObjects2.length = 0;
gdjs._50Code.GDCarRedObjects1.length = 0;
gdjs._50Code.GDCarRedObjects2.length = 0;
gdjs._50Code.GDConvertiblePurpleObjects1.length = 0;
gdjs._50Code.GDConvertiblePurpleObjects2.length = 0;
gdjs._50Code.GDConvertibleBlueObjects1.length = 0;
gdjs._50Code.GDConvertibleBlueObjects2.length = 0;
gdjs._50Code.GDAmphibiousCarBlueObjects1.length = 0;
gdjs._50Code.GDAmphibiousCarBlueObjects2.length = 0;
gdjs._50Code.GDCarBlueObjects1.length = 0;
gdjs._50Code.GDCarBlueObjects2.length = 0;
gdjs._50Code.GDCoupeBlueObjects1.length = 0;
gdjs._50Code.GDCoupeBlueObjects2.length = 0;
gdjs._50Code.GDF1CarLightBlueObjects1.length = 0;
gdjs._50Code.GDF1CarLightBlueObjects2.length = 0;
gdjs._50Code.GDF1CarBrownObjects1.length = 0;
gdjs._50Code.GDF1CarBrownObjects2.length = 0;
gdjs._50Code.GDF1CarRedObjects1.length = 0;
gdjs._50Code.GDF1CarRedObjects2.length = 0;
gdjs._50Code.GDCoupeYellowObjects1.length = 0;
gdjs._50Code.GDCoupeYellowObjects2.length = 0;
gdjs._50Code.GDJeepBriteGreenObjects1.length = 0;
gdjs._50Code.GDJeepBriteGreenObjects2.length = 0;
gdjs._50Code.GDFuelSemiTruckObjects1.length = 0;
gdjs._50Code.GDFuelSemiTruckObjects2.length = 0;
gdjs._50Code.GDJeepGreenObjects1.length = 0;
gdjs._50Code.GDJeepGreenObjects2.length = 0;
gdjs._50Code.GDMuscleCarBlueObjects1.length = 0;
gdjs._50Code.GDMuscleCarBlueObjects2.length = 0;
gdjs._50Code.GDSedanGreenObjects1.length = 0;
gdjs._50Code.GDSedanGreenObjects2.length = 0;
gdjs._50Code.GDMuscleCarYellowObjects1.length = 0;
gdjs._50Code.GDMuscleCarYellowObjects2.length = 0;
gdjs._50Code.GDSedanGreyObjects1.length = 0;
gdjs._50Code.GDSedanGreyObjects2.length = 0;
gdjs._50Code.GDSuvTanObjects1.length = 0;
gdjs._50Code.GDSuvTanObjects2.length = 0;
gdjs._50Code.GDSportsCarGreyObjects1.length = 0;
gdjs._50Code.GDSportsCarGreyObjects2.length = 0;
gdjs._50Code.GDSemiTruckObjects1.length = 0;
gdjs._50Code.GDSemiTruckObjects2.length = 0;
gdjs._50Code.GDSportsCarOrangeObjects1.length = 0;
gdjs._50Code.GDSportsCarOrangeObjects2.length = 0;
gdjs._50Code.GDSportsCarRedObjects1.length = 0;
gdjs._50Code.GDSportsCarRedObjects2.length = 0;
gdjs._50Code.GDSportsCarLightYellowObjects1.length = 0;
gdjs._50Code.GDSportsCarLightYellowObjects2.length = 0;
gdjs._50Code.GDTankObjects1.length = 0;
gdjs._50Code.GDTankObjects2.length = 0;
gdjs._50Code.GDSportsCarYellowObjects1.length = 0;
gdjs._50Code.GDSportsCarYellowObjects2.length = 0;
gdjs._50Code.GDTruckObjects1.length = 0;
gdjs._50Code.GDTruckObjects2.length = 0;
gdjs._50Code.GDWoodenCarObjects1.length = 0;
gdjs._50Code.GDWoodenCarObjects2.length = 0;
gdjs._50Code.GDBush2Objects1.length = 0;
gdjs._50Code.GDBush2Objects2.length = 0;
gdjs._50Code.GDBush1Objects1.length = 0;
gdjs._50Code.GDBush1Objects2.length = 0;
gdjs._50Code.GDBush3Objects1.length = 0;
gdjs._50Code.GDBush3Objects2.length = 0;
gdjs._50Code.GDHomeObjects1.length = 0;
gdjs._50Code.GDHomeObjects2.length = 0;
gdjs._50Code.GDEdgeObjects1.length = 0;
gdjs._50Code.GDEdgeObjects2.length = 0;

gdjs._50Code.eventsList0(runtimeScene);

return;

}

gdjs['_50Code'] = gdjs._50Code;
