gdjs.carCode = {};


gdjs.carCode.eventsList0 = function(runtimeScene) {

};

gdjs.carCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.carCode.eventsList0(runtimeScene);

return;

}

gdjs['carCode'] = gdjs.carCode;
