gdjs._48Code = {};
gdjs._48Code.GDNewTextObjects1= [];
gdjs._48Code.GDNewTextObjects2= [];


gdjs._48Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};

gdjs._48Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._48Code.GDNewTextObjects1.length = 0;
gdjs._48Code.GDNewTextObjects2.length = 0;

gdjs._48Code.eventsList0(runtimeScene);

return;

}

gdjs['_48Code'] = gdjs._48Code;
